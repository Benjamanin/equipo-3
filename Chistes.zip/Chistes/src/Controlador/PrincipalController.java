/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author zhomb
 */
public class PrincipalController implements Initializable {

    @FXML
    private Button btnSi;

    private Stage stage;
   
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Mostrar_Chiste(ActionEvent event)throws IOException{
        
        //Cuando aprete el boton SI, se ejecutara otra ventana con los chistes y esta se cerrrara.
        
       FXMLLoader loader = new FXMLLoader(getClass().getResource("/Vista/chistes.fxml"));
        Parent root = loader.load();
        ChistesController controller = loader.getController();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
        
        Stage mystage = (Stage) this.btnSi.getScene().getWindow();
        mystage.close();    //Cerramos actual ventana
    }

    public void setStage(Stage primaryStage) {
        stage = primaryStage;
    }
    
}
