/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author zhomb
 */
public class ChistesController implements Initializable {

    @FXML
    private Label texto; //un solo label que dependiendo la variable "CambiarChiste" en el switch se le seteara un chiste diferente.
    
    /*Label[] arreglo = new Label[4];   No pudimos resolverlo con arreglo de label. Pero, la logica era que cada vez que se presione el boton
                                        el arreglo aumente y pueda mostrar otro chiste*/
    
    @FXML
    private Button btnO_C;
    
    private int cambiarChiste=0;
    @FXML
    private Label lblContador;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Mostrat_O_Chiste(ActionEvent event) {
        
         /*Cada vez que se presione el boton "btnO_C" la variable cambiarChiste aumentara en 1, por lo cual, cada vez por el SWITCH
            se mostrara un chiste diferente al otro.
        */   
        
            switch(cambiarChiste){
                case 0: texto.setText("He cambiado mi contraseña a \"incorrecta\". Así, cada vez que me \n olvido de ella, el ordenador dice \"Su contraseña es incorrecta\".");
                        lblContador.setText("(1/5)");
                    break;
                case 1: texto.setText("He introducido lo que he comido hoy en mi nueva aplicación de \n fitness y acaba de enviar una ambulancia a mi casa");
                    lblContador.setText("(2/5)");
                    break;
                case 2: texto.setText("¿Cuántos programadores hacen falta para cambiar una bombilla? \n Ninguno, porque es un problema de hardware.");
                    lblContador.setText("(3/5)");
                    break;
                case 3: texto.setText("La barriga de un programador es directamente proporcional a la \n cantidad de información que maneja.");
                    lblContador.setText("(4/5)");
                    break;
                case 4: texto.setText("¿Por qué tiras los ordenadores al río? \n Porque ¡mira como beben los PCs en el río!.");
                    lblContador.setText("(5/5)");
                        cambiarChiste=-1; //Cuando la variable "CambiarChiste" llegue al ultimo chiste, entonces el asignaremos un valor -1,para que,
                                           //Cuando salga del switch sume 1 (-1+1=0), asi se repetira el chiste desde el principio.
                    break;
                
                 
            
        }
            cambiarChiste=cambiarChiste+1;
            
    
    }
    
}
